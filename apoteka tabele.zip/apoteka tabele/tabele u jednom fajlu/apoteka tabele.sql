-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: apoteka
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `korisnik`
--

DROP TABLE IF EXISTS `korisnik`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `korisnik` (
  `username` varchar(30) NOT NULL,
  `lozinka` varchar(15) DEFAULT NULL,
  `ime` varchar(45) DEFAULT NULL,
  `prezime` varchar(45) DEFAULT NULL,
  `tip` varchar(15) DEFAULT NULL,
  `obrisan` tinyint DEFAULT '1',
  PRIMARY KEY (`username`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `korisnik`
--

LOCK TABLES `korisnik` WRITE;
/*!40000 ALTER TABLE `korisnik` DISABLE KEYS */;
INSERT INTO `korisnik` VALUES ('admin','admin','Jana','Jovanovic','Administrator',1),('aleksandra','aleksandra','Aleksandra','Bobic','Apotekar',1),('mile','mile','Milivoje','Rajic','Lekar',1),('rade','rade','Radomir','Gajic','Apotekar',1),('tamara','tamara','Tamara','Djordjevic','Lekar',1);
/*!40000 ALTER TABLE `korisnik` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lek`
--

DROP TABLE IF EXISTS `lek`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lek` (
  `sifra` varchar(15) NOT NULL,
  `ime` varchar(45) DEFAULT NULL,
  `proizvodjac` varchar(45) DEFAULT NULL,
  `recept` tinyint DEFAULT NULL,
  `cena` float DEFAULT NULL,
  `obrisan` tinyint DEFAULT '1',
  PRIMARY KEY (`sifra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lek`
--

LOCK TABLES `lek` WRITE;
/*!40000 ALTER TABLE `lek` DISABLE KEYS */;
INSERT INTO `lek` VALUES ('1','brufen','galenika',1,100,1),('10','Providon','sss',0,123,1),('11','Espumisan','Galenika',0,600,1),('12','xx','xx',0,234,1),('2','c vitamin','galenika',0,200,1),('3','cardiopirin','alkaloid',0,210,0),('6','Febricet','Tamara Produce',0,456,1),('7','Panadol','ddd',1,234,1),('8','Propoli','ddd',1,789,1),('9','Espumisan','Galenika',1,600,1),('novo','jana','banana',1,555,1),('saq','Kafetin','gfgfd',0,234,1);
/*!40000 ALTER TABLE `lek` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `racun`
--

DROP TABLE IF EXISTS `racun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `racun` (
  `sifra` int NOT NULL AUTO_INCREMENT,
  `apotekar` varchar(40) DEFAULT NULL,
  `kupac` varchar(40) DEFAULT NULL,
  `datum` datetime(6) DEFAULT NULL,
  `listaproizvoda` text,
  `ukupno` float DEFAULT NULL,
  `obrisan` tinyint DEFAULT '1',
  PRIMARY KEY (`sifra`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `racun`
--

LOCK TABLES `racun` WRITE;
/*!40000 ALTER TABLE `racun` DISABLE KEYS */;
INSERT INTO `racun` VALUES (1,'Bojana',NULL,'2020-06-28 00:00:00.000000','xx?3?-Espumisan?1?-c vitamin?1?-',1502,1),(2,'Bojana',NULL,'2020-06-28 00:00:00.000000','xx?3?-Espumisan?1?-c vitamin?1?-',1502,1),(3,'Bojana',NULL,'2020-06-28 00:00:00.000000','xx?3?-Espumisan?1?-c vitamin?1?-',1502,1),(4,'Bojana',NULL,'2020-06-28 00:00:00.000000','xx?2?-Febricet?2?-',1380,1),(5,'Bojana','mima','2020-06-28 00:00:00.000000','Providon?2?-cardiopirin?2?-',699.3,1),(6,'Bojana','mima','2020-06-28 00:00:00.000000','Espumisan?2?-cardiopirin?2?-',1701,1),(7,'Bojana','mima','2020-06-28 00:00:00.000000','Febricet?1?-cardiopirin?2?-',919.8,1),(8,'Bojana','mima','2020-06-28 00:00:00.000000','Providon?2?-cardiopirin?2?-',1140.3,1),(9,'Bojana','mima','2020-06-28 00:00:00.000000','Providon?2?-cardiopirin?2?-',0,1),(10,'Bojana','mare','2020-06-28 00:00:00.000000','xx?2?-cardiopirin?2?-',843.6,1),(11,'Bojana','mare','2020-06-28 00:00:00.000000','Espumisan?1?-',570,1),(12,'Bojana','mima','2020-06-29 00:00:00.000000','brufen?3?-cardiopirin?6?-',1404,1),(13,'Bojana','mima','2020-06-29 00:00:00.000000','xx?2?-Panadol?2?-Espumisan?2?-',1922.4,1),(14,'Bojana','sale','2020-06-29 00:00:00.000000','cardiopirin?2?-',399,1),(15,'Bojana','mima','2020-06-29 00:00:00.000000','cardiopirin?2?-',336,1),(16,'Bojana','mare','2020-06-29 00:00:00.000000','Espumisan?4?-c vitamin?2?-Providon?1?-',5330.7,1),(17,'Bojana','mare','2020-06-29 00:00:00.000000','Propoli?1?-brufen?4?-Panadol?2?-Espumisan?2?-c vitamin?3?-',2765.6,1),(18,'Bojana','majica','2020-06-29 00:00:00.000000','Espumisan?1?-',1140,1),(19,'Bojana','mima','2020-06-29 00:00:00.000000','Kafetin?1?-c vitamin?3?-',667.2,1),(20,'Bojana','nebo','2020-06-29 00:00:00.000000','Propoli?1?-brufen?4?-Panadol?2?-Espumisan?2?-c vitamin?3?-',5165.15,1),(21,'Kaligula',NULL,'2020-06-30 00:00:00.000000','Espumisan?2?-Providon?2?-cardiopirin?1?-',1779,1),(22,'rade',NULL,'2020-08-21 00:00:00.000000','c vitamin?5?-',1000,1),(23,'rade',NULL,'2020-08-21 00:00:00.000000','Febricet?5?-Kafetin?5?-c vitamin?5?-',4450,1),(24,'rade','darko','2020-08-21 00:00:00.000000','xx?5?-Kafetin?5?-Espumisan?5?-',5073,1),(25,'rade',NULL,'2020-08-21 00:00:00.000000','Febricet?4?-Espumisan?4?-',4224,1),(26,'rade','darko','2020-08-21 00:00:00.000000','Espumisan?5?-',2400,1);
/*!40000 ALTER TABLE `racun` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recept`
--

DROP TABLE IF EXISTS `recept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recept` (
  `sifra` int NOT NULL AUTO_INCREMENT,
  `lekar` varchar(45) DEFAULT NULL,
  `jmbg` varchar(45) DEFAULT NULL,
  `datum` datetime DEFAULT NULL,
  `lekovi` text,
  `ukupno` float DEFAULT NULL,
  `obrisan` tinyint DEFAULT '1',
  PRIMARY KEY (`sifra`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recept`
--

LOCK TABLES `recept` WRITE;
/*!40000 ALTER TABLE `recept` DISABLE KEYS */;
INSERT INTO `recept` VALUES (1,'Milan','1298765','2019-08-05 00:00:00','brufen?3?-cardiopirin?6?-',100,1),(2,'Goran','34212','2017-09-07 00:00:00','c vitamin?2-oldon?1-',300,1),(3,'Mikica','76876','2020-06-29 00:00:00','xx?2?-Panadol?2?-Espumisan?2?-',2136,1),(4,'Mikica','34343431','2020-06-29 00:00:00','cardiopirin?2?-',420,1),(5,'Milka','3432','2020-06-29 00:00:00','Propoli?1?-brufen?4?-Panadol?2?-Espumisan?2?-c vitamin?3?-',3457,1),(6,'Mikica','23434325','2020-06-29 00:00:00','xx?1?-Febricet?1?-Kafetin?1?-Panadol?1?-c vitamin?3?-Providon?1?-',1881,1),(7,'mile','100298742234','2020-08-21 00:00:00','Kafetin?1?-Propoli?1?-',1023,1);
/*!40000 ALTER TABLE `recept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vipkartica`
--

DROP TABLE IF EXISTS `vipkartica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vipkartica` (
  `sifra` int NOT NULL AUTO_INCREMENT,
  `kupac` varchar(40) DEFAULT NULL,
  `datum` datetime(6) DEFAULT NULL,
  `iznos` float DEFAULT NULL,
  `obrisan` tinyint DEFAULT '1',
  PRIMARY KEY (`sifra`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vipkartica`
--

LOCK TABLES `vipkartica` WRITE;
/*!40000 ALTER TABLE `vipkartica` DISABLE KEYS */;
INSERT INTO `vipkartica` VALUES (1,'darko','2020-08-21 00:00:00.000000',5073,1),(2,'darko','2020-08-21 00:00:00.000000',2400,1),(3,'mima','2020-06-28 00:00:00.000000',0,1),(4,'mare','2020-06-28 00:00:00.000000',843.6,1),(5,'mare','2020-06-28 00:00:00.000000',570,1),(6,'mima','2020-06-29 00:00:00.000000',1404,1),(7,'mima','2020-06-29 00:00:00.000000',1922.4,1),(8,'sale','2020-06-29 00:00:00.000000',399,1),(9,'mima','2020-06-29 00:00:00.000000',336,1),(10,'mare','2020-06-29 00:00:00.000000',5330.7,1),(11,'mare','2020-06-29 00:00:00.000000',2765.6,1),(12,'majica','2020-06-29 00:00:00.000000',1140,1),(13,'mima','2020-06-29 00:00:00.000000',667.2,1),(14,'nebo','2020-06-29 00:00:00.000000',5165.15,1);
/*!40000 ALTER TABLE `vipkartica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vipkorisnici`
--

DROP TABLE IF EXISTS `vipkorisnici`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vipkorisnici` (
  `username` varchar(40) NOT NULL,
  `ime` varchar(45) DEFAULT NULL,
  `prezime` varchar(45) DEFAULT NULL,
  `obrisan` tinyint DEFAULT '1',
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vipkorisnici`
--

LOCK TABLES `vipkorisnici` WRITE;
/*!40000 ALTER TABLE `vipkorisnici` DISABLE KEYS */;
INSERT INTO `vipkorisnici` VALUES ('darko','darko','sanicanin',1),('majica','Maja','Pavlovic',1),('mare','Marko','Pavkov',1),('mima','Milan','milic',1),('nebo','Nebojsa','Stojic',1),('sale','Sasa','Saskovic',1);
/*!40000 ALTER TABLE `vipkorisnici` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-21 23:43:32
